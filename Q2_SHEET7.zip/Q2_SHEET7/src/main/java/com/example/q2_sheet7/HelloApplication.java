import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class BackgroundColorChange extends Application {

    private Pane pane;

    @Override
    public void start(Stage primaryStage) {
        pane = new Pane();
        pane.setMinWidth(400);
        pane.setMinHeight(400);
        pane.setStyle("-fx-background-color: white;");

        pane.setOnMousePressed((MouseEvent event) -> {
            pane.setStyle("-fx-background-color: black;");
        });

        pane.setOnMouseReleased((MouseEvent event) -> {
            pane.setStyle("-fx-background-color: white;");
        });

        Scene scene = new Scene(pane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Background Color Change");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}