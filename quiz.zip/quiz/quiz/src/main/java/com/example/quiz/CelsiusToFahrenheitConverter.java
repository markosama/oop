package com.example.quiz;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class CelsiusToFahrenheitConverter extends Application {

    @Override
    public void start(Stage stage)
    {
        Label title = new Label("Fahrenheit Calculator");
        title.setFont(new Font("Arial", 20));
        title.setTextAlignment(TextAlignment.CENTER);

        Label celsiusLabel = new Label("Celsius");
        Label fahrenheitLabel = new Label("Fahrenheit");

        TextField celsiusTextField = new TextField();
        Label fahrenheitResultLabel = new Label();

        Button convertButton = new Button("Convert");
        convertButton.setOnAction(e -> {
            double celsius = Double.parseDouble(celsiusTextField.getText());
            double fahrenheit = (celsius * 9 / 5) + 32;
            fahrenheitResultLabel.setText(String.format("%.2f", fahrenheit));
        });
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(title, celsiusLabel, celsiusTextField, fahrenheitLabel, fahrenheitResultLabel, convertButton);
        Scene scene = new Scene(layout);
        stage.setScene(scene);
        stage.setTitle("Fahrenheit Calculator");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
