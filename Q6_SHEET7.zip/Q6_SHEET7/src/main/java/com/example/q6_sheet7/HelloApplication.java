import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class InvestmentValueCalculator extends Application {

    private TextField investmentAmountField;
    private TextField numberOfYearsField;
    private TextField annualInterestRateField;
    private TextField futureValueField;

    @Override
    public void start(Stage primaryStage) {
        GridPane root = new GridPane();
        root.setPadding(new Insets(10));
        root.setVgap(10);
        root.setHgap(10);

        Label investmentAmountLabel = new Label("Investment Amount:");
        investmentAmountField = new TextField();

        Label numberOfYearsLabel = new Label("Number of Years:");
        numberOfYearsField = new TextField();

        Label annualInterestRateLabel = new Label("Annual Interest Rate:");
        annualInterestRateField = new TextField();

        Button calculateButton = new Button("Calculate");
        calculateButton.setOnAction(event -> calculateFutureValue());

        Label futureValueLabel = new Label("Future Value:");
        futureValueField = new TextField();
        futureValueField.setEditable(false);

        GridPane.setConstraints(investmentAmountLabel, 0, 0);
        GridPane.setConstraints(investmentAmountField, 1, 0);
        GridPane.setConstraints(numberOfYearsLabel, 0, 1);
        GridPane.setConstraints(numberOfYearsField, 1, 1);
        GridPane.setConstraints(annualInterestRateLabel, 0, 2);
        GridPane.setConstraints(annualInterestRateField, 1, 2);
        GridPane.setConstraints(calculateButton, 1, 3);
        GridPane.setConstraints(futureValueLabel, 0, 4);
        GridPane.setConstraints(futureValueField, 1, 4);

        root.getChildren().addAll(
                investmentAmountLabel, investmentAmountField,
                numberOfYearsLabel, numberOfYearsField,
                annualInterestRateLabel, annualInterestRateField,
                calculateButton,
                futureValueLabel, futureValueField
        );

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Investment Value Calculator");
        primaryStage.show();
    }

    private void calculateFutureValue() {
        double investmentAmount = Double.parseDouble(investmentAmountField.getText());
        int numberOfYears = Integer.parseInt(numberOfYearsField.getText());
        double annualInterestRate = Double.parseDouble(annualInterestRateField.getText());

        double monthlyInterestRate = annualInterestRate / 12 / 100;
        double futureValue = investmentAmount * Math.pow(1 + monthlyInterestRate, numberOfYears * 12);

        futureValueField.setText(String.format("%.2f", futureValue));
    }

    public static void main(String[] args) {
        launch(args);
    }
}