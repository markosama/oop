module com.example.q4_sheet7 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.q4_sheet7 to javafx.fxml;
    exports com.example.q4_sheet7;
}