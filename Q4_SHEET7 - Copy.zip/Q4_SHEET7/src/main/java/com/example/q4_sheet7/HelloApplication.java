import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TextCaseConverter extends Application {

    private TextField textField;

    @Override
    public void start(Stage primaryStage) {
        VBox root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);

        textField = new TextField();

        Button upperCaseButton = new Button("Upper Case");
        upperCaseButton.setOnAction(event -> {
            String text = textField.getText();
            String upperCaseText = text.toUpperCase();
            textField.setText(upperCaseText);
        });

        Button lowerCaseButton = new Button("Lower Case");
        lowerCaseButton.setOnAction(event -> {
            String text = textField.getText();
            String lowerCaseText = text.toLowerCase();
            textField.setText(lowerCaseText);
        });

        root.getChildren().addAll(textField, upperCaseButton, lowerCaseButton);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Text Case Converter");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}