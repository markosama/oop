module com.example.q3_sheet7 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.q3_sheet7 to javafx.fxml;
    exports com.example.q3_sheet7;
}