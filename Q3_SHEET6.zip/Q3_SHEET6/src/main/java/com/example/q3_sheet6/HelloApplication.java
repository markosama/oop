import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.Random;

public class VerticalTextDisplay extends Application {

    private static final String[] TEXTS = {"Hello", "World", "JavaFX", "OpenAI", "Programming"};
    private static final int FONT_SIZE = 22;

    @Override
    public void start(Stage primaryStage) {
        VBox vBox = new VBox();
        vBox.setSpacing(10);

        Random random = new Random();

        for (String text : TEXTS) {
            Text textNode = new Text(text);
            textNode.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, FONT_SIZE));
            textNode.setFill(getRandomColor(random));
            textNode.setOpacity(getRandomOpacity(random));
            vBox.getChildren().add(textNode);
        }

        Scene scene = new Scene(vBox);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Vertical Text Display");
        primaryStage.show();
    }

    private Color getRandomColor(Random random) {
        return Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }

    private double getRandomOpacity(Random random) {
        return random.nextDouble();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
