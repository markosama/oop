import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CircleTextDisplay extends Application {

    private static final String TEXT = "Welcome to Java";
    private static final int CIRCLE_RADIUS = 150;
    private static final int FONT_SIZE = 16;
    private static final int ANGLE_OFFSET = -90;
    private static final int TEXT_SPACING = 360 / TEXT.length();

    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, CIRCLE_RADIUS * 2, CIRCLE_RADIUS * 2);

        Circle circle = new Circle(CIRCLE_RADIUS, CIRCLE_RADIUS, CIRCLE_RADIUS, Color.TRANSPARENT);
        circle.setStroke(Color.BLACK);
        root.getChildren().add(circle);

        for (int i = 0; i < TEXT.length(); i++) {
            double angle = i * TEXT_SPACING + ANGLE_OFFSET;
            double x = CIRCLE_RADIUS + CIRCLE_RADIUS * Math.cos(Math.toRadians(angle));
            double y = CIRCLE_RADIUS + CIRCLE_RADIUS * Math.sin(Math.toRadians(angle));

            Text text = new Text(x, y, String.valueOf(TEXT.charAt(i)));
            text.setFont(Font.font(FONT_SIZE));
            root.getChildren().add(text);
        }

        primaryStage.setScene(scene);
        primaryStage.setTitle("Circle Text Display");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}