module com.example.q4_sheet_6 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.q4_sheet_6 to javafx.fxml;
    exports com.example.q4_sheet_6;
}