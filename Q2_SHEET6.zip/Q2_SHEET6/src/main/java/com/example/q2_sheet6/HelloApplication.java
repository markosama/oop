package com.example.q2_sheet6;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Random;

public class TicTacToeBoard extends Application {

    private static final String X_IMAGE_FILE = "x.gif";
    private static final String O_IMAGE_FILE = "o.gif";
    private static final int BOARD_SIZE = 3;

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Random random = new Random();

        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                ImageView cellImageView = new ImageView();
                cellImageView.setFitWidth(50);
                cellImageView.setFitHeight(50);

                int randomNum = random.nextInt(3);
                if (randomNum == 0) {
                    cellImageView.setImage(new Image(X_IMAGE_FILE));
                } else if (randomNum == 1) {
                    cellImageView.setImage(new Image(O_IMAGE_FILE));
                }

                gridPane.add(cellImageView, col, row);
            }
        }

        Scene scene = new Scene(gridPane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Tic Tac Toe Board");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
}