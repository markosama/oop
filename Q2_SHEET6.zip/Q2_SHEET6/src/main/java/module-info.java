module com.example.q2_sheet6 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.q2_sheet6 to javafx.fxml;
    exports com.example.q2_sheet6;
}